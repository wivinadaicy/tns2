<section id="about" class="cd-section">
<div class="row" style = "margin-bottom:10%;margin-top:10%">
    <div class="col-md-6 animate-box">
        <div class="video colorlib-video" style="background-image: url(assets/img/about.jpg);" data-aos="fade-right" data-aos-delay="300">
            <div class="overlay"></div>
        </div>
    </div>
    <div class="col-md-6 animate-box">
        <h2 data-aos="fade-down"><?php echo $lang['judulttg'];?></h2>
        <p style = "text-align: justify; text-align-last:left" data-aos="fade-up" data-aos-delay="300"><?php echo $lang['ttg'];?></p>
    </div>
</div>
</section>