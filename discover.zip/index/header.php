<section id="home" class="video-hero cd-section" style="height: 600px; background-image: url(assets/img/cover_img_1.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
    <div class="overlay" style = "height:100%;margin:0;padding:0"></div>
    <div class="display-t text-center">
        <div class="display-tc">
            <div class="container">
                <div class="col-md-12 col-md-offset-0">
                    <div class="animate-box">
                        <h2 style = "color:#007348" data-aos="fade-down"><?php echo $lang['judulbesar'];?></h2>
                        <p style ="text-align: justify; text-align-last:center; font-size:20px; color:#008755"data-aos="fade-up"><?php echo $lang['tagjudulbesar'];?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>