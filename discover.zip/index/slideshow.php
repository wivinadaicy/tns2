<div class="colorlib-featured cd-section" id="photos" data-aos="fade-up">
    <div class="row animate-box">
        <div class="featured-wrap">
            <div class="owl-carousel">
                <div class="item">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="featured-entry">
                            <img class="img-responsive" src="assets/img/H.E Gary Quinlan AO-Tirta B.Wirawan-H.E Jean Charles Berthonnet.jpeg" alt="">
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="featured-entry">
                            <img class="img-responsive" src="assets/img/Marco Vezzoso , Tirta BambangWirawan , Michela Linda Magri Alessandro Collina.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="featured-entry">
                            <img class="img-responsive" src="assets/img/Dr. Micheal Rauner-Tirta B.Wirawan-Paulus B.Wirawan.jpeg" alt="">
                        </div>
                    </div>
                </div>
                <div class="item">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="featured-entry">
                            <img class="img-responsive" src="assets/img/Dr. Rudy Salahudin-Taufik Darusman-Tirta B. Wirawan-Dato Sri Tahir.jpeg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>