
        <div class="row col-md-8 col-md-offset-2 text-center colorlib-heading animate-box">
                <h2><?php echo $lang['judulvisimisi'];?></h2>
                <p><?php echo $lang['visimisi'];?></p>
        </div>

