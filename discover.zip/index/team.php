<div class="row">
    <div class="container">
					<div class="col-md-4 text-center animate-box">
						<div class="staff-entry">
							<a href="#" class="staff-img" style="background-image: url(assets/img/tirtaProfile.jpg);"></a>
							<div class="desc">
								<h3>Tirta Bambang Wirawan</h3>
								<span>CHAIRMAN</span>
                                <ul class="colorlib-social-icons">
                                    <li><a href="#"><i class="icon-twitter"></i></a></li>
                                    <li><a href="#"><i class="icon-facebook"></i></a></li>
                                    <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                    <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                </ul>
							</div>
						</div>
					</div>
					<div class="col-md-4 text-center animate-box">
						<div class="staff-entry">
							<a href="#" class="staff-img" style="background-image: url(assets/img/sherinaProfile.jpg);"></a>
							<div class="desc">
								<h3>Sherina Salamon</h3>
								<span>CEO</span>
                                <ul class="colorlib-social-icons">
                                    <li><a href="#"><i class="icon-twitter"></i></a></li>
                                    <li><a href="#"><i class="icon-facebook"></i></a></li>
                                    <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                    <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                </ul>
							</div>
						</div>
					</div>
					<div class="col-md-4 text-center animate-box">
						<div class="staff-entry">
							<a href="#" class="staff-img" style="background-image: url(assets/img/paulusProfile.jpg);"></a>
							<div class="desc">
								<h3>Paulus B. Wirawan</h3>
								<span>SR. VICE PRESIDENT</span>
								<ul class="colorlib-social-icons">
                                    <li><a href="#"><i class="icon-twitter"></i></a></li>
                                    <li><a href="#"><i class="icon-facebook"></i></a></li>
                                    <li><a href="#"><i class="icon-linkedin"></i></a></li>
                                    <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                </ul>
							</div>
						</div>
					</div>
        </div>
				</div>