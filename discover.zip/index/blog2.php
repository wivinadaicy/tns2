<br>
<br>

<div class="row" data-aos = "">
    <div class="col-md-8 col-md-offset-2 text-center colorlib-heading animate-box">
        <h2><?php echo $lang['judulhistory'];?></h2>
    </div>
</div>