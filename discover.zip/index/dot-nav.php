	<nav id="cd-vertical-nav">
		<ul style="list-style-type:none;">
			<li style="color: #007348">
				<a href="#home" data-number="1">
					<span class="cd-dot"></span>
					<span class="cd-label">Intro</span>
				</a>
			</li>
			<li style="color: #007348">
				<a href="#photos" data-number="2">
					<span class="cd-dot"></span>
					<span class="cd-label">Photos</span>
				</a>
			</li>
			<li style="color: #007348">
				<a href="#about" data-number="4">
					<span class="cd-dot"></span>
					<span class="cd-label">About</span>
				</a>
			</li>
			<li style="color: #007348">
				<a href="#ourvalues" data-number="5">
					<span class="cd-dot"></span>
					<span class="cd-label">Our Values</span>
				</a>
			</li>
		</ul>
	</nav>