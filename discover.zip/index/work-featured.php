<div class="colorlib-work-featured colorlib-bg-white cd-section" id="visimisi">
        <div class="row mobile-wrap">
            <div class="container">
                <?php include('index/blog.php');?>
                <div class="col-md-5 animate-box">
                    <div class="mobile-img" style="background-image: url(assets/img/mobile-2.jpg);"></div>
                </div>
                <div class="col-md-7 animate-box">
                    <div class="desc">
                        <h2><?php echo $lang['judulvisi'];?></h2>
                            <div class="f-desc" style="text-align:justify;">
                                <p><?php echo $lang['visi'];?></p>
                            </div>
                        <h2><?php echo $lang['judulmisi'];?></h2>
                            <div class="f-desc">
                                <p><?php echo $lang['misi'];?></p>
                            </div>
                    </div>
                </div>
            </div>
        </div>
</div>