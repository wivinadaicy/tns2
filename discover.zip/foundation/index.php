<div class="colorlib-intro" style = "overflow:hidden;background-image: url(assets/img/mobile-2.jpg); filter:alpha(opacity=100); background-size:cover; height:100%">
    <div class="row mobile-wrap" style = "Background-color:White; position:Absolute; height:100%; width:100%; padding:0px; margin:0px; margin-top:0px; opacity:0.9;overflow:hidden;">
        <div class="container"></div>
    </div>
    <div class="container" style = "padding-top:100px">
        <div class="row">
            <div class="col-md-8 col-md-offset-2 text-center colorlib-heading animate-box">
                <h2  data-aos="zoom-in"><?php echo $lang['tnsfondasi'];?></h2>
                <p style = "text-align:justify; text-align-last:center"   data-aos="zoom-out"><?php echo $lang['jelasfondasi'];?>
                </p>
            </div>
        </div>
        <br/>
        <br/>
        <div class="row">
            <div class="col-md-2 col-sm-12 text-center animate-box">
                <div class="services">
                    <span class="icon">
                    </span>
                    <div class="desc">
                        <h3 style = "font-size:25px"><?php echo $lang['star'];?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-12  text-center animate-box">
                <div class="services">
                    <span class="icon">
                    </span>
                    <div class="desc">
                        <h3 style = "font-size:25px"><?php echo $lang['manu'];?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-2 col-sm-12  text-center animate-box">
                <div class="services">
                    <span class="icon">
                    </span>
                    <div class="desc">
                        <h3 style = "font-size:25px"><?php echo $lang['edu'];?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12  text-center animate-box">
                <div class="services">
                    <span class="icon">
                    </span>
                    <div class="desc">
                        <h3 style = "font-size:25px"><?php echo $lang['air'];?></h3>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-12 text-center animate-box">
                <div class="services">
                    <span class="icon">
                    </span>
                    <div class="desc">
                        <h3 style = "font-size:25px"><?php echo $lang['decent'];?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>