<!-- dipakai sesuai kebutuhan -->
<section id="home" class="video-hero" style="height: 500px; background-image: url(assets/img/cover_img_1.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
<div class="overlay"></div>
    <div class="display-t display-t2 text-center">
        <div class="display-tc display-tc2">
            <div class="container">
                <div class="col-md-12 col-md-offset-0">
                    <div class="animate-box">
                        <h2 style = "color:#007748"><span><strong><?php echo $lang['tns'];?></strong></span> <?php echo $lang['fondasi'];?></h2>
                        <p class="breadcrumbs"><span><a href="index.php" style = "color:#007748"><?php echo $lang['home'];?></a></span><span><a href="discover.php" style = "color:#007748"><?php echo $lang['tagtemukan'];?></a></span><span style = "color:#007748"><strong><?php echo $lang['tns'];?> <?php echo $lang['fondasi'];?></strong></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>