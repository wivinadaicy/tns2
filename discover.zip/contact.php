<?php session_start(); $_SESSION["page"] = "contact";?>
<?php include('configlang.php');?>
<?php include('req/head.php'); ?>
<?php include('req/nav.php'); ?>
<?php include('contact/page-info.php'); ?>
<!-- content -->
<?php include('req/content-open.php');?>
<?php include('contact/index.php'); ?>
<?php include('req/content-close.php');?>
<!-- end content-->
<?php include('req/footer.php'); ?>
<?php include('req/web-close.php'); ?>
<?php include('req/script.php'); ?>