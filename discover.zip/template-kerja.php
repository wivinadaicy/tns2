<?php include('req/head.php'); ?>
<?php include('req/nav.php'); ?>
<!-- content -->
<?php include('req/content-open');?>
<?php include('req/content-close');?>
<!-- end content-->
<?php include('req/footer.php'); ?>
<?php include('req/web-close.php'); ?>
<?php include('req/script.php'); ?>