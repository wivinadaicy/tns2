<div class="colorlib-intro" style = "margin-top:50px">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center colorlib-heading animate-box">
                <h2  data-aos="flip-up"><?php echo $lang['whatmatter'];?></h2>
                <p data-aos="flip-down"><strong><?php echo $lang['tagwhatproperty'];?></strong></p>
                <p  data-aos="flip-down" style ="text-align:justify; text-align-last:center"><?php echo $lang['deswhatproperty'];?></p>
            </div>
        </div>
    </div>
</div>