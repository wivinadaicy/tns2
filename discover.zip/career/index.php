<div class="row" style = "margin-top:50px">
    <div class="col-md-10 col-md-offset-1 text-center colorlib-heading animate-box">
        <p style = "text-align: justify; text-align-last:center; font-size:20px"  data-aos="zoom-out"><?php echo $lang['karirdes'];?></p>
    </div>
</div>
<div class="row" style = "margin-bottom:50px">
    <h3 class="text-center"  data-aos="zoom-in"><?php echo $lang['worldneed'];?></h3>
    <p class="text-center"  data-aos="zoom-in" data-aos-delay="400"><?php echo $lang['cv'];?> <a href="mailto:tnsgruppe@outlook.com">tnsgruppe@outlook.com</a></p>
</div>