<div class="row" style = "margin-top:50px">
    <div class="col-md-8 col-md-offset-2 text-center colorlib-heading animate-box">
        <h2 data-aos="zoom-in-down"><?php echo $lang['direk'];?></h2>
        <p data-aos="zoom-in-up"><?php echo $lang['behind'];?></p>
    </div>
</div>
<div class="row" style = "Background-color:none">
    <div class="col-md-12 col-sm-12 text-center animate-box" style = "cursor:pointer" onclick="location.href='profile.php?id=1'" >
        <a href="profile.php?id=1" class="staff-img col-lg-4" style = "overflow:hidden;padding:20px"><img src = "assets/img/tirtaProfile.jpg" style = "width:100%" data-aos="zoom-in-right"></a>
        <div class="desc col-lg-8" style = "text-align:left;padding:20px" data-aos="zoom-in-left">
            <h3>Tirta B. Wirawan</h3>
            <span><?php echo $lang['chair'];?></span>
        </div>
    </div>
</div>
<br/>
<div class="row" style = "Background-color:none">
    <div class="col-md-12 col-sm-12 text-center animate-box" style = "cursor:pointer" onclick="location.href='profile.php?id=2'" >
        <a href="profile.php?id=2" class="staff-img col-lg-4" style = "overflow:hidden;padding:20px"><img src = "assets/img/sherinaProfile.jpg" style = "width:100%" data-aos="zoom-in-right"></a>
        <div class="desc col-lg-8" style = "text-align:left;padding:20px" data-aos="zoom-in-left">
            <h3>Sherina Salamon</h3>
            <span><?php echo $lang['ceo'];?></span>
        </div>
    </div>
</div>
<br/>
<div class="row" style = "Background-color:none">
    <div class="col-md-12 col-sm-12 text-center animate-box" style = "cursor:pointer" onclick="location.href='profile.php?id=2'" >
        <a href="profile.php?id=3" class="staff-img col-lg-4" style = "overflow:hidden;padding:20px"><img src = "assets/img/paulusProfile.jpg" style = "width:100%" data-aos="zoom-in-right"></a>
        <div class="desc col-lg-8" style = "text-align:left;padding:20px" data-aos="zoom-in-left">
            <h3>Paulus B. Wirawan</h3>
            <span><?php echo $lang['srvp'];?></span>
        </div>
    </div>
</div>