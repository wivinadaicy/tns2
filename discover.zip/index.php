<?php session_start(); $_SESSION["page"] = "glance";?>
<?php include('configlang.php'); ?>

<?php include('req/head.php'); ?>
<?php include('req/nav.php'); ?>
<!-- content -->
<?php include('index/dot-nav.php'); ?>
<?php include('index/slideshow.php');?>
<?php include('index/header.php');?>
<?php include('req/content-open.php');?>



<?php include('index/about.php');?>

<?php include('index/service.php'); ?> <!--value-->

<?php //include('index/team.php');?>


<?php include('req/content-close.php');?> 
<!-- end content-->
<?php include('req/footer.php');?>
<?php include('req/web-close.php'); ?>
<?php include('req/script.php'); ?>