<div class="row" style = "margin:50px">
    <div class="col-md-12 text-center colorlib-heading animate-box">
        <p style = "text-align:justify; text-align-last:center; font-size:20px"   data-aos="fade-up"><?php echo $lang['deswhatmakes'];?></p>
    </div>
</div>