<!-- dipakai sesuai kebutuhan -->
<section id="home" class="video-hero" style="height: 500px; background-image: url(assets/img/cover_img_1.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
<div class="overlay"></div>
    <div class="display-t display-t2 text-center">
        <div class="display-tc display-tc2">
            <div class="container">
                <div class="col-md-12 col-md-offset-0">
                    <div class="animate-box">
                        <h2><span style = "font-weight:100;color:#007748"  data-aos="fade-up"><?php echo $lang['judulwhatmakes'];?></span></h2>
                        <p class="breadcrumbs"  data-aos="fade-down"><span><a style = "color:#007748" href="index.php"><?php echo $lang['home'];?></a></span><span style = "color:#007748"><strong><?php echo $lang['tagwhatmakes'];?></strong></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>