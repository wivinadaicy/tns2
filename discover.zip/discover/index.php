<div class="row" style = "margin-top:50px">
    <div class="col-md-6 text-center animate-box" onclick = "location.href='property.php'" style = "cursor:pointer">
        <div class="services"  data-aos="flip-left">
            <span class="icon">
                <i class="icon-earth" style = "color:#007748"></i>
            </span>
            <div class="desc" >
                <h3>T&amp;S PROPERTY</h3>
                <p><strong>YOUR PRIVATE REALTOR</strong><br/>T&amp;S Property has always been your reference in private realtor, based on a solid Indonesian Heritage </p>
            </div>
        </div>
    </div>
    <div class="col-md-6 text-center animate-box" onclick = "location.href='foundation.php'" style = "cursor:pointer">
        <div class="services"  data-aos="flip-right">
            <span class="icon">
                <i class="icon-man-woman" style = "color:#007748"></i>
            </span>
            <div class="desc">
                <h3>T&amp;S FOUNDATION</h3>
                
                <p><strong>T&amp;S REAL CONTRIBUTION</strong><br/>T&amp;S INTERNATIONAL Group will establish a foundation under the auspices of T&amp;S INTERNATIONAL Group</p>
            </div>
        </div>
    </div>
</div>