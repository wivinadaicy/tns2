<?php session_start(); $_SESSION["page"] = "glance";?>
<?php include('configlang.php'); ?>
<?php include('req/head.php');?>
<?php include('req/nav.php');?>
<?php include('vision/index.php');?>
<?php include('req/footer.php');?>
<?php include('req/web-close.php');?>
<?php include('req/script.php');?>