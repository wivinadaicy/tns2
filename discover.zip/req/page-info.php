<!-- dipakai sesuai kebutuhan -->
<section id="home" class="video-hero" style="height: 500px; background-image: url(assets/images/cover_img_1.jpg);  background-size:cover; background-position: center center;background-attachment:fixed;" data-section="home">
<div class="overlay"></div>
    <div class="display-t display-t2 text-center">
        <div class="display-tc display-tc2">
            <div class="container">
                <div class="col-md-12 col-md-offset-0">
                    <div class="animate-box">
                        <h2><strong>DISCOVER</strong> <span style = "font-weight:100;">T&amp;S</span></h2>
                        <p class="breadcrumbs"><span><a href="index.php">Home</a></span><span><strong>Discover</strong></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>