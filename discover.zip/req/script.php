    <script src="assets/js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="assets/js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="assets/js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="assets/js/jquery.stellar.min.js"></script>
	<!-- YTPlayer -->
	<script src="assets/js/jquery.mb.YTPlayer.min.js"></script>
	<!-- Owl carousel -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- Magnific Popup -->
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/magnific-popup-options.js"></script>
	<!-- Counters -->
	<script src="assets/js/jquery.countTo.js"></script>
	<!-- Main -->
	<script src="assets/js/main.js"></script>

<script src="assets/js/jquery-2.1.1"></script>
<script src="assets/js/mainx1"></script>
<script src="assets/js/mainx2"></script>
<script src="assets/js/main-dot.js"></script>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();
</script>