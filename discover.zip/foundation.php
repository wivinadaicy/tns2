<?php session_start(); $_SESSION["page"] = "discover";?>
<?php include('configlang.php'); ?>
<?php include('req/head.php');?>
<?php include('req/nav.php');?>

<?php include('foundation/page-info.php');?>
<?php include('foundation/index.php');?>

<?php include('req/web-close.php');?>
<?php include('req/script.php');?>
<?php include('req/footer.php');?>