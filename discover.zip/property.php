<?php session_start(); $_SESSION["page"] = "discover";?>
<?php include('configlang.php'); ?>
<?php include('req/head.php');?>
<?php include('req/nav.php');?>
<?php include('property/page-info.php');?>
<?php include('property/intro.php');?>
<?php include('property/index.php');?>

<?php include('req/web-close.php');?>
<?php include('req/script.php');?>