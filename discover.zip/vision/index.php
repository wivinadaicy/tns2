
<div class="colorlib-work-featured" id="visimisi" style = "overflow:hidden;background-image: url(assets/img/vision.jpg); filter:alpha(opacity=100); background-size:cover; height:100%">
    <div class="row mobile-wrap" style = "Background-color:White; position:Absolute; height:100%; width:100%; padding:0px; margin:0px; margin-top:0px; opacity:0.9;overflow:hidden;">
        <div class="container"></div>
    </div>
    <div class="row mobile-wrap" style = "margin-top:100px;overflow:hidden;">
        <div class="container">
            <div class="col-md-12 animate-box">
                <div class="desc">
                    <h2><?php echo $lang['judulvisi'];?></h2>
                        <div class="f-desc" style="text-align:justify;">
                            <p><?php echo $lang['visi'];?></p>
                        </div>
                    <h2><?php echo $lang['judulmisi'];?></h2>
                        <div class="f-desc">
                            <p><?php echo $lang['misi'];?></p>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>

